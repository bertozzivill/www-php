<?php

namespace Vinelab\Rss\Exceptions;

class InvalidFeedChannelException extends RssException
{
}
