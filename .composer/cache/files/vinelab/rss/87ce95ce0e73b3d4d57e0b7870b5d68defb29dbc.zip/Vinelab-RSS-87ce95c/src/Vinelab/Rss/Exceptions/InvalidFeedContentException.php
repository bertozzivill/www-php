<?php

namespace Vinelab\Rss\Exceptions;

class InvalidFeedContentException extends RssException
{
}
