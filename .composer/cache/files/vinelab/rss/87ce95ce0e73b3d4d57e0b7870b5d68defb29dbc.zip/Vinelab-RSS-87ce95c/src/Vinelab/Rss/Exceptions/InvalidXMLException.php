<?php

namespace Vinelab\Rss\Exceptions;

class InvalidXMLException extends RssException
{
}
