<?php namespace Vinelab\Http\Tests\Server;

print json_encode($_GET);