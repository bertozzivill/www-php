<?php namespace Vinelab\Http\Tests\Server;

header('Content-Type: application/json');