<?php namespace Vinelab\Http\Tests\Server;

print_r($_GET);